import torch
import math


def createDatabase():
    firstCoord = torch.add(torch.mul(torch.rand(1000), 20), -10)
    secondCoord = torch.add(torch.mul(torch.rand(1000), 20), -10)
    pi = torch.full_like(secondCoord, math.pi)

    functionArguments = torch.addcdiv(firstCoord, secondCoord, pi)
    functionResults = torch.sin(functionArguments)

    permanent = torch.column_stack((firstCoord, secondCoord, functionResults))
    torch.save(permanent, '../mydataset.txt')

    print(permanent)


if __name__ == '__main__':
    createDatabase()
