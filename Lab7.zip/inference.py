import math

import torch

from network import myModel

if __name__ == '__main__':
    # we load the model

    filepath = "myNet.pt"
    ann = myModel.Net(2, 10, 10, 10, 1)

    ann.load_state_dict(torch.load(filepath))
    ann.eval()

    # visualise the parameters for the ann (aka weights and biases)
    # for name, param in ann.named_parameters():
    #     if param.requires_grad:
    #         print (name, param.data)

    done = False
    while not done:
        i = input("x1 = ")
        j = input("x2 = ")
        if i == 'done' or j == 'done':
            done = True
            continue

        x1 = float(i)
        x2 = float(j)
        x = torch.tensor([x1, x2])
        print('Predicted: ')
        print('\t' + str(ann(x).tolist()))

        res = math.sin(x1 + x2 / math.pi)
        print('Real value: ')
        print('\t' + str(res))
