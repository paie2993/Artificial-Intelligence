# -*- coding: utf-8 -*-

# Creating some colors
BLUE = (0, 0, 255)
GRAYBLUE = (50, 120, 120)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# define directions
UP = 0
DOWN = 2
LEFT = 1
RIGHT = 3

# define indexes variations
v = [[-1, 0], [1, 0], [0, 1], [0, -1]]

# define map size


# define square size
U = 20

# functionality constants
RANDOM_MAP_FILL = 0.2
MAP_LENGTH = 20
INITIAL_X = 5
INITIAL_Y = 5

NO_ITERATIONS = 100

NO_CITIES = 5
GENERATION_EXIT = 5000

# constant for operations determining the movement of the ant between the cities
Q0 = 0.4
ALHPA = 0.7
BETA = 1.4
GAMMA = 2

# constant determining the behaviour of the colony:
ITERATIONS = 50 # how many times to send ants
ANTS_PER_ITERATION = 20 # how many ants

PHEROMONE_ADDITION = 1
INITIAL_PHEROMONE = 0.1
PHEROMONE_DEGRADATION_COEFFICTIENT = 0.4

DRONE_BATTERY = 60
CITY_RANGE = 5
STARTING = "STARTING"
SENSOR = "SENSOR"
CTIY_TYPES = [STARTING, SENSOR]
