import datetime

from repository import *


class Controller:
    def __init__(self, repository=Repository()):
        self.__repository = repository

    def getRepository(self):
        return self.__repository

