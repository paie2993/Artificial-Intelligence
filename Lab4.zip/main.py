from utils import *
from domain import *
from gui import *

if __name__ == "__main__":
    print("Hello mister")
    print()

    # map initialization
    _map = Map()
    _map.randomMap()

    print("The map is:")
    print(str(_map))

    #
    #
    # -----------
    x = INITIAL_X
    y = INITIAL_Y
    # as long as the initial coordinates are not valid on a map, generate another map
    i = 0
    while not _map.isValid([x, y]) and i < GENERATION_EXIT:
        _map.randomMap()
        i = i + 1

    if not _map.isValid([x, y]):
        print("Try again, or change the configuration file. Problem: initial coordinates are not valid for " + str(
            GENERATION_EXIT) + "map(s) generated")
        exit(1)

    #
    #
    # cities initialization
    starting_city = City(x, y)
    starting_city.set_type(STARTING)

    cities = generate_cities(_map)
    cities.append(starting_city)

    #
    #
    # 'place' cities on the map (actually mark the position where cities are found)
    _map.place_cities(cities)
    # find what is the maximum number of square that can be seen from each city
    for city in cities:
        city.compute_visible(_map)
        pass


    #
    #
    # get the dictionary of edges, containing the actual shortest paths between each two cities
    edge_dictionary = get_edge_dictionary(_map, cities)
    print("The edges between the cities are: ")
    print(str(edge_dictionary))

    print("================================================")
    print("================================================")
    print("================================================")

    colony = Colony(starting_city, edge_dictionary)

    for i in range(0, ITERATIONS):
        colony.iteration()

    ant = colony.get_one_of_best_ants()
    path = ant.get_path()

    movingDrone(_map, path, edge_dictionary)

    print("Bye mister")

