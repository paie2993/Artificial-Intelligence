import pygame
import time
from utils import *
from domain import *


def initPyGame(dimension=MAP_LENGTH):
    # init the pygame
    pygame.init()
    logo = pygame.image.load("logo32x32.png")
    pygame.display.set_icon(logo)
    pygame.display.set_caption("drone exploration")

    # create a surface on screen that has the size of 800 x 480
    screen = pygame.display.set_mode(dimension)
    screen.fill(WHITE)
    return screen


def closePyGame():
    # closes the pygame
    running = True
    # loop for events
    while running:
        # event handling, gets all event from the event queue
        for event in pygame.event.get():
            # only do something if the event is of type QUIT
            if event.type == pygame.QUIT:
                # change the value to False, to exit the main loop
                running = False
    pygame.quit()


# preconditions: length of path >= 2
def movingDrone(currentMap, path, edge_dictionary):
    if len(path) < 2:
        raise Exception("The path must contain at least two cities")

    # animation of a drone on a path
    screen = initPyGame((currentMap.n * U, currentMap.m * U))

    drona = pygame.image.load("drona.png")

    for i in range(0, len(path) - 1):
        cityA = path[i]
        cityB = path[i + 1]

        edge_endpoints = EdgeEndpoints(cityA, cityB)
        edge = edge_dictionary[edge_endpoints]

        actual_path = edge.get_path()
        copy_path = [square for square in actual_path]

        first_square = copy_path[0]
        dummy_city = City(first_square[0], first_square[1])

        if not cityA == dummy_city:
            copy_path.reverse()

        for square in copy_path:
            screen.blit(image(currentMap), (0, 0))

            screen.blit(drona, (square[1] * U, square[0] * U))
            pygame.display.flip()

            time.sleep(0.1)

    closePyGame()


def image(currentMap, brickColor=BLUE, cityColor=RED, backgroundColor=WHITE):
    # creates the image of a map
    imagine = pygame.Surface((currentMap.n * U, currentMap.m * U))
    brick = pygame.Surface((U, U))
    city = pygame.Surface((U, U))
    brick.fill(brickColor)
    city.fill(cityColor)
    imagine.fill(backgroundColor)
    for i in range(currentMap.n):
        for j in range(currentMap.m):
            if currentMap.surface[i][j] == 1:  # if the algorithm iterates over a brick, paint it
                imagine.blit(brick, (j * 20, i * 20))
            elif currentMap.surface[i][j] == 2:
                imagine.blit(city, (j * 20, i * 20))
    return imagine
