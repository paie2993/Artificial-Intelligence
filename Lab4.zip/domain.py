from random import randint, random
from utils import *


class Map:
    def __init__(self, n=MAP_LENGTH, m=MAP_LENGTH):
        self.n = n
        self.m = m
        self.surface = [[0 for j in range(m)] for i in range(n)]

    def randomMap(self, fill=RANDOM_MAP_FILL):
        for i in range(self.n):
            for j in range(self.m):
                if random() <= fill:
                    self.surface[i][j] = 1

    def place_cities(self, cities):
        for city in cities:
            self.surface[city.get_x()][city.get_y()] = 2

    def isValid(self, square):
        if 0 <= square[0] < self.n and 0 <= square[1] < self.m:
            if self.surface[square[0]][square[1]] != 1:
                return True
        return False

    def __str__(self):
        string = ""
        for i in range(self.n):
            for j in range(self.m):
                string = string + str(int(self.surface[i][j]))
            string = string + "\n"
        return string


# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================


class City:
    def __init__(self, x, y):
        self.__x = x
        self.__y = y
        self.__type = None
        self.__visible = 0

    def get_x(self):
        return self.__x

    def get_y(self):
        return self.__y

    def get_type(self):
        return self.__type

    def set_type(self, city_type):
        if city_type not in CTIY_TYPES:
            raise Exception('Type not valid: ' + city_type)
        self.__type = city_type

    def get_visible(self):
        return self.__visible

    # precondition: receives a Map instance
    #               the coordinates of the City are valid in the _map
    # postcondition: sets the __visible field to the number of visible squares, from the city, for the input _map
    #                considers that the maximum number of squares that can be seen on the same line is CITY_RANGE
    def compute_visible(self, _map):
        total = 0
        for direction in v:
            current_square = [self.__x + direction[0], self.__y + direction[1]]
            while _map.isValid(current_square):
                total += 1
                current_square = [current_square[0] + direction[0], current_square[1] + direction[1]]
        self.__visible = total

    def __hash__(self):
        return hash(self.__x + self.__y)

    def __eq__(self, city):
        return self.__x == city.__x and self.__y == city.__y

    def __str__(self):
        return "City " + str(self.__x) + " " + str(self.__y)


class EdgeEndpoints:
    def __init__(self, cityA, cityB):
        self.__cityA = cityA
        self.__cityB = cityB

    def get_cityA(self):
        return self.__cityA

    def get_cityB(self):
        return self.__cityB

    def __contains__(self, city):
        return city == self.__cityA or city == self.__cityB

    def __hash__(self):
        return hash(hash(self.__cityA) + hash(self.__cityB))

    def __eq__(self, other):
        return (self.__cityA == other.__cityA and self.__cityB == other.__cityB) or \
               (self.__cityA == other.__cityB and self.__cityB == other.__cityA)

    def __str__(self):
        return str(self.__cityA) + " <-> " + str(self.__cityB)


class Edge:
    def __init__(self, edge_endpoints, path, pheromone=INITIAL_PHEROMONE):
        # edge_endpoints stores the two cities connected by the edge
        # path stores the actual path on the map between two cities (square by square)
        self.__edge_endpoints = edge_endpoints
        self.__path = path
        # we assume that any path passed to the constructor has at least two elements
        if len(path) < 2:
            raise Exception("Could not construct Edge: path has a lenght less than 2 --- " + str(len(path)))
        self.__cost = len(self.__path) - 1
        self.__pheromone = pheromone

    def get_edge_endpoints(self):
        return self.__edge_endpoints

    def get_path(self):
        return self.__path

    def get_cost(self):
        return self.__cost

    def get_pheromone(self):
        return self.__pheromone

    def set_pheromone(self, pheromone):
        self.__pheromone = pheromone

    def add_pheromone(self, additional_pheromone):
        self.__pheromone += additional_pheromone

    def evaporate_pheromone(self):
        new_value = (1 - PHEROMONE_DEGRADATION_COEFFICTIENT) * \
                    self.__pheromone + PHEROMONE_DEGRADATION_COEFFICTIENT * INITIAL_PHEROMONE
        if new_value < INITIAL_PHEROMONE:
            self.__pheromone = INITIAL_PHEROMONE
        else:
            self.__pheromone = new_value

    def __eq__(self, other, path=False, pheromone=False):
        result = self.__edge_endpoints == other.__edge_endpoints
        if path:
            result = result and self.__path == other.__path
        if pheromone:
            result = result and self.__pheromone == other.__pheromone
        return result

    def __str__(self):
        return "Edge:\n" + \
               "\tEndpoints: " + str(self.__edge_endpoints) + "\n" + \
               "\tPath: " + str(self.__path) + "\n" + \
               "\tPheromone: " + str(self.__pheromone)


class EdgeDictionary:
    def __init__(self):
        self.__edge_dictionary = dict()

    # postconditions: returns a list with all the cities
    def get_cities(self):
        cities = []
        for edge_endpoints in self.__edge_dictionary:
            cityA = edge_endpoints.get_cityA()
            cityB = edge_endpoints.get_cityB()
            if cityA not in cities:
                cities.append(cityA)
            if cityB not in cities:
                cities.append(cityB)
        return cities

    def __iter__(self):
        for edge_endpoints in self.__edge_dictionary:
            yield edge_endpoints

    def __getitem__(self, edge_endpoints):
        return self.__edge_dictionary[edge_endpoints]

    def __setitem__(self, edge_endpoints, edge):
        self.__edge_dictionary[edge_endpoints] = edge

    def __str__(self):
        string = ""
        for key in self.__edge_dictionary:
            string = string + "( " + str(key) + " )" + " -> " + str(self.__edge_dictionary[key]) + "\n"
        return string


# =======================================================================================================================
# =======================================================================================================================
# ============================xxxxxxxxxxxxxxxxxxxx=======================================================================
# =====================xxxxxx A* search algorithm  xxxxxxxx==============================================================
# ============================xxxxxxxxxxxxxxxxxxxx=======================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================


def h_compute(starting, ending):
    return abs(starting[0] - ending[0]) + abs(starting[1] - ending[1])


def get_min_f(open_list, f_cost):
    current = open_list[0]
    for square in open_list:
        if f_cost[square[0]][square[1]] < f_cost[current[0]][current[1]]:
            current = square
    return current


def shortest_path(_map, cityA, cityB):
    INF = 9999

    starting = cityA
    ending = cityB

    open_list = [[starting.get_x(), starting.get_y()]]

    came_from = [[None for j in range(0, _map.m)] for i in range(0, _map.n)]

    g_cost = [[INF for j in range(0, _map.m)] for i in range(0, _map.n)]
    g_cost[cityA.get_x()][cityA.get_y()] = 0

    f_cost = [[INF for j in range(0, _map.m)] for i in range(0, _map.n)]
    f_cost[cityA.get_x()][cityA.get_y()] = h_compute([cityA.get_x(), cityA.get_y()], [cityB.get_x(), cityB.get_y()])

    while len(open_list) != 0:
        current = get_min_f(open_list, f_cost)

        if current == [ending.get_x(), ending.get_y()]:
            break

        open_list.remove(current)

        for direction in v:
            successor = [current[0] + direction[0], current[1] + direction[1]]

            if not _map.isValid(successor):
                continue

            tentative_g_cost = g_cost[current[0]][current[1]] + 1  # the step size
            if tentative_g_cost < g_cost[successor[0]][successor[1]]:
                came_from[successor[0]][successor[1]] = current
                g_cost[successor[0]][successor[1]] = tentative_g_cost
                f_cost[successor[0]][successor[1]] = tentative_g_cost + h_compute(successor,
                                                                                  [ending.get_x(), ending.get_y()])
                if successor not in open_list:
                    open_list.append(successor)

    path = []

    current = [ending.get_x(), ending.get_y()]
    if came_from[current[0]][current[1]] is not None:
        while current is not None:
            path.append(current)
            current = came_from[current[0]][current[1]]

    path.reverse()
    return path


# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================


class Ant:
    def __init__(self, path, edge_dictionary):
        self.__path = path
        self.__edge_dictionary = edge_dictionary
        self.__battery = DRONE_BATTERY

    def get_path(self):
        return self.__path

    def set_path(self, path):
        self.__path = path

    def set_edge_dictionary(self, edge_dictionary):
        self.__edge_dictionary = edge_dictionary

    def get_battery(self):
        return self.__battery

    def decrement_battery(self):
        if self.__battery - 1 < 0:
            raise Exception("Battery can't be less than 0: " + str(self.__battery - 1))
        self.__battery -= 1

    def drain_battery(self, energy):
        if self.__battery - energy < 0:
            raise Exception("Battery can't be less than 0: " + str(self.__battery - 1))
        self.__battery -= energy

    def set_battery(self, battery):
        self.__battery = battery

    # preconditions:
    #   the 'path' must be non-empty
    #   the 'path' must not contain all the cities in the edge_dictionary; it should not contain at least one city
    # postcondition:
    #   adds a new city to the 'path'
    #   returns the edge traversed by the ant
    def move(self):
        if len(self.__path) == 0:
            raise Exception("The path of the ant should contain at least one city")

        # the city in which the and is currently
        current_city = self.__path[-1]

        temp_dictionary = dict()
        # the ant will only work with cities it hasn't visited yet, and which it can access from
        # the current city, at every iteration
        for edge_endpoints in self.__edge_dictionary:
            cityA = edge_endpoints.get_cityA()
            cityB = edge_endpoints.get_cityB()
            if cityA == current_city and cityB not in self.__path or cityB == current_city and cityA not in self.__path:
                temp_dictionary[edge_endpoints] = self.__edge_dictionary[edge_endpoints]
        # here, temp_dictionary contains only the edges the ant could take

        if len(temp_dictionary.keys()) == 0:
            raise Exception("The ant should have at the very least one more city to visit. Logical error")

        # the random number which will determine how the ant chooses its next city
        q = random()

        next_city = None
        next_edge = None

        # first case: selecting the next city deterministically
        if q < Q0:

            # the most profitable city will be chosen, the one having the maximum profit at the end
            maximum = 0

            for edge_endpoints in temp_dictionary:
                edge = temp_dictionary[edge_endpoints]

                cityA = edge.get_edge_endpoints().get_cityA()
                cityB = edge.get_edge_endpoints().get_cityB()
                tentative_city = cityA if current_city == cityB else cityB

                # how desireable is a city
                cost = (edge.get_pheromone() ** ALHPA) * ((1 / edge.get_cost()) ** BETA) * (
                        tentative_city.get_visible() / (len(v) * CITY_RANGE) ** GAMMA)
                if maximum < cost:
                    maximum = cost
                    next_city = tentative_city
                    next_edge = edge

        # second case: selecting the next city based on probabilities
        else:

            sum_of_posibilities = 0
            sum_of_probabilities = 0
            r = random()

            # compute the denominator
            for edge_endpoints in temp_dictionary:
                edge = temp_dictionary[edge_endpoints]
                cost = (edge.get_pheromone() ** ALHPA) * ((1 / len(edge.get_path())) ** BETA)
                sum_of_posibilities = sum_of_posibilities + cost

            # do a rulete selection
            for edge_endpoints in temp_dictionary:
                edge = temp_dictionary[edge_endpoints]
                cost = (edge.get_pheromone() ** ALHPA) * ((1 / len(edge.get_path())) ** BETA)
                probability = cost / sum_of_posibilities
                sum_of_probabilities += probability
                if sum_of_probabilities >= r:
                    next_edge = edge
                    break

            cityA = next_edge.get_edge_endpoints().get_cityA()
            cityB = next_edge.get_edge_endpoints().get_cityB()
            next_city = cityA if current_city == cityB else cityB

        self.__path.append(next_city)
        return next_edge


class Colony:
    def __init__(self, starting_city, edge_dictionary):
        self.__starting_city = starting_city
        self.__ants = []
        self.__edge_dictionary = edge_dictionary
        self.__cities = self.__edge_dictionary.get_cities()

    def get_one_of_best_ants(self):
        maximum = 0
        best_ant = None
        for ant in self.__ants:
            if len(ant.get_path()) > maximum:
                maximum = len(ant.get_path())
                best_ant = ant
        return best_ant

    def iteration(self):
        for i in range(0, ANTS_PER_ITERATION):
            ant = Ant([self.__starting_city], self.__edge_dictionary)
            self.__ants.append(ant)

        # delete ants which have completed their journey
        to_delete = []
        for i in range(0, len(self.__ants)):
            ant_path = self.__ants[i].get_path()
            if len(ant_path) == len(self.__cities):
                to_delete.append(i)
        to_delete.reverse()
        for i in to_delete:
            self.__ants.pop(i)

        # let each ant move towards one city
        affected_edges = []
        for ant in self.__ants:
            edge = ant.move()
            affected_edges.append(edge)

        # add pheromone to each edge that has been traversed
        for edge in affected_edges:
            edge.add_pheromone(PHEROMONE_ADDITION)

        # degrade the pheromone of each edge
        for edge_endpoints in self.__edge_dictionary:
            edge = self.__edge_dictionary[edge_endpoints]
            edge.evaporate_pheromone()


# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================
# =======================================================================================================================

# function to generate N cities (as specified in the utils.py file)
def generate_cities(_map):
    cities = []

    j = 0
    while len(cities) < NO_CITIES and j < GENERATION_EXIT:
        x = randint(0, _map.n - 1)
        y = randint(0, _map.m - 1)

        i = 0
        while not _map.isValid([x, y]) and i < GENERATION_EXIT:
            x = randint(0, _map.n - 1)
            y = randint(0, _map.m - 1)
            i = i + 1

        if _map.isValid([x, y]):
            city = City(x, y)
            if city not in cities:
                city.set_type(SENSOR)
                cities.append(city)

        j = j + 1

    if len(cities) == NO_CITIES:
        return cities
    else:
        raise Exception("Could not generate cities")


# function to get the shortes paths (i.e. the edges in this problem) between each two cities:
def get_edge_dictionary(_map, cities):
    if len(cities) <= 1:
        raise Exception("Not enough cities. There are " + str(len(cities)) + " for this run.")

    # initialize the dictionary of edges
    edge_dictionary = EdgeDictionary()

    for i in range(0, len(cities)):
        for j in range(i + 1, len(cities)):
            cityA = cities[i]
            cityB = cities[j]

            path = shortest_path(_map, cityA, cityB)
            if len(path) == 0:
                raise Exception(
                    "Path could not be found between " + str(cityA) + " and " + str(cityB) + ". Try another run")

            print("Path between city " + str(cityA) + " and city " + str(cityB) + " has been found")
            edge_endpoints = EdgeEndpoints(cityA, cityB)
            edge = Edge(edge_endpoints, path)

            # add an edge to the dictionary of edges
            edge_dictionary[edge_endpoints] = edge

    print()
    return edge_dictionary
