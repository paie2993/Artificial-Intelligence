import csv
from random import random, choice

import numpy as np
from scipy.spatial.distance import cdist
from sklearn.decomposition import PCA
from tqdm import trange
import matplotlib.pyplot as plt


class Cluster:
    def __init__(self, centroid):
        self.centroid = centroid
        self.data = []


def KMeans(x, k, no_of_iterations):
    # choose random centroids
    cid = np.random.choice(len(x), k, replace=False)

    centroids = []
    for i in cid:
        centroids.append(x[i])

    # the clusters are stored in a dict, having the centroids as keys
    clusters = dict()

    for _ in trange(no_of_iterations):

        # create the clusters
        clusters = dict()
        for i in range(len(centroids)):
            clusters[i] = Cluster(centroids[i])

        # distance between centroids and all the data points
        distances = cdist(x, centroids, 'euclidean')

        # mapping between each data element and its centroid
        for i in range(len(x)):

            # find the closest centroid to which the data element belongs
            minimum = 0
            for j in range(len(centroids)):

                # i = index of the data element
                # j = index of the distance to centroid
                if distances[i][j] < distances[i][minimum]:
                    minimum = j

            # map data element to centroid
            clusters[minimum].data.append(x[i])

        newCentroids = []
        # recompute the centroids:
        for c in clusters:
            temp_cent = np.mean(clusters[c].data, axis=0)
            newCentroids.append(temp_cent)
        # replace previous centroids:
        centroids = newCentroids

    return clusters


def readPoints():
    readClusters = {'A': [], 'B': [], 'C': [], 'D': []}
    points = []
    with open('dataset.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            points.append([float(row[1]), float(row[2])])
            readClusters[row[0]].append([float(row[1]), float(row[2])])
    return points, readClusters


# labels the elements in the found clusters
def labeling(readClusters, labels):
    for c in labels:
        label = None
        data = labels[c].data
        for point in data:
            for rCluster in readClusters:
                if point in readClusters[rCluster]:
                    label = rCluster
                    break
            if label is not None:
                point.insert(0, label)
                break
            else:
                point.insert(0, None)


def displayScatterPlot(labels):
    i = 0
    markers = ['^', '*', 'o', 'x']
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22',
              '#17becf']
    for l in labels:
        cluster = labels[l]
        N = len(cluster.data)

        # extract points
        x = [d[0] for d in cluster.data]
        y = [d[1] for d in cluster.data]

        # Complete the scatter plot
        r = choice(colors)
        plt.scatter(x, y, s=[(i + 1) * 2 ** 2 for _ in range(N)], c=[r for _ in range(N)], marker=markers[i])
        i = i + 1

    # plt.legend()
    plt.show()


def computeAccuracyIndex(readClusters, labels):
    pass


if __name__ == "__main__":
    # load data
    points, readClusters = readPoints()

    # # transform the data aka fit the model with X and apply the dimensionality reduction on X
    # pca = PCA(2)
    # df = pca.fit_transform(points)

    # cluster points
    labels = KMeans(points, 4, 1000)

    # labeling(readClusters, labels)
    # print(labels)

    # display scatter plot
    displayScatterPlot(labels)
