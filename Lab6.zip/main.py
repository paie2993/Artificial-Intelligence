from random import random

import numpy as np
import matplotlib.pyplot as plt

if __name__ == '__main__':

    # N = 50
    # x = np.random.rand(N)
    # y = np.random.rand(N)

    x = [0.2, 0.5, 0.7]
    y = [0.1, 0.3, 0.7]

    area = 1 ** 2  # 0 to 15 point radii

    plt.scatter(x, y, s=area, c=[random(), random(), random()], alpha=0.5)
    plt.show()